﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    class LoggingClass: ILog
    {
         public void Log(string txt)
         {
            InternalLog(txt);
         }

        public void LogFormat(string txt,params object[] args)
        {
            string msg = string.Format(txt, args);
            InternalLog(msg);
        }
        private StreamWriter streamWriter;
        private void InternalLog(string txt)
        {
            if (streamWriter==null)
            {
                streamWriter = new StreamWriter("LogFile.log");
            }
            streamWriter.WriteLine(txt);
            streamWriter.Flush();
        }
    }
}
