﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    internal class ServiceLocator
    {
        private static readonly Hashtable services = new Hashtable();

        public static void AddService<T>(T service)
        {
            services.Add(typeof(T).Name, service);
        }

        public static void AddService<T>(string name, T service)
        {
            services.Add(name, service);
        }

        public static T GetService<T>()
        {
            return (T)services[typeof(T).Name];
        }
        public static T GetService<T>(string serviceName)
        {
            return (T)services[serviceName];
        }

        public static void RegisterServiceFromAppSettings(string serviceName)
        {
            var loggerEntry = System.Configuration.ConfigurationSettings.AppSettings["serviceName"];
            var logObject = Assembly.GetExecutingAssembly().CreateInstance(loggerEntry);
            AddService(serviceName, logObject);
        }
    }
}
