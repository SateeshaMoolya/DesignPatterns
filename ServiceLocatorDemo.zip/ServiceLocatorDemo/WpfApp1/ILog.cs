﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1
{
    interface ILog
    {
        void Log(string txt);
        void LogFormat(string txt, params object[] args);
    }
}
