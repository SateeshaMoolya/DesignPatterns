﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
[assembly: log4net.Config.XmlConfigurator(Watch = true)]
namespace WpfApp1
{

    class LogAdapter : ILog
    {
        private static log4net.ILog log = log4net.LogManager.GetLogger(typeof(LogAdapter));
        public void Log(string txt)
        {
            log.Debug(txt);
        }

        public void LogFormat(string txt, params object[] args)
        {
            log.DebugFormat(txt, args);
        }
    }
}
